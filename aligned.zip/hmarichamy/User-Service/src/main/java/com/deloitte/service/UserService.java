package com.deloitte.service;

import java.util.List;

import com.deloitte.dto.IssueDto;
import com.deloitte.dto.LoginRequestDto;
import com.deloitte.dto.UserDto;
import com.deloitte.dto.UserRequestDto;

public interface UserService {

 UserDto addUser(UserRequestDto request);
 List<UserDto> getAllUsers();
 UserDto getUserById(Integer userId);
 UserDto login(LoginRequestDto request);
 List<IssueDto> getIssuesByUserId(Integer userId);
 List<IssueDto> getIssuesByUsername(String username);
}
