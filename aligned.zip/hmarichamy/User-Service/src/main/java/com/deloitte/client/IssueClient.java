package com.deloitte.client;


import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.deloitte.dto.IssueDto;


@FeignClient(name = "ISSUE-SERVICE")
public interface IssueClient {

    @GetMapping("/api/v1/issues/assignee/{assignee}")
    List<IssueDto> getIssuesByAssignee(
            @PathVariable("assignee") Integer assignee);
}