package com.deloitte.dto;
import java.time.LocalDate;
public class ProjectDto {

    private Integer id;

    private String projectName;

    private Integer projectOwner;

    private LocalDate startDate;

    private LocalDate endDate;
    
}