package com.deloitte.exception;

public class ProjectException extends RuntimeException{
	public ProjectException(String message) {
		super(message);
	}

}
