package com.deloitte.client;


import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.deloitte.dto.IssueDto;


@FeignClient(name = "issue-service")
public interface IssueClient {

    @GetMapping("/api/v1/issues/project/{projectId}")
    List<IssueDto> getIssuesByProject(
            @PathVariable("projectId") Integer projectId);
}