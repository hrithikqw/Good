package com.deloitte.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.deloitte.entity.Issue;


public interface IssueRepository extends JpaRepository<Issue, Integer> {

    List<Issue> findByProjectId(Integer projectId); 

    List<Issue> findByAssignee(Integer assignee);

    List<Issue> findByCreatedBy(Integer createdBy);

    List<Issue> findByProjectIdAndAssignee(
            Integer projectId,
            Integer assignee);
}