package com.deloitte.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.entity.Issue;
import com.deloitte.exception.IssueException;
import com.deloitte.repository.IssueRepository;

@Service
public class IssueServiceImpl implements IssueService {

    @Autowired
    private IssueRepository issueRepository;

    @Override
    public Issue addIssue(Issue issue) {
        if (issue.getProjectId() == null) {
            throw new IssueException(
                "Project ID is required"
            );
        }
        if (issue.getSummary() == null ||
            issue.getSummary().isBlank()) {

            throw new IssueException(
                "Issue summary is required"
            );
        }
        if (issue.getCreatedOn() == null) {
            issue.setCreatedOn(LocalDate.now());
        }        issue.setLastUpdated(LocalDate.now());
        return issueRepository.save(issue);
    }
    
    @Override
    public List<Issue> getAllIssues() {

        return issueRepository.findAll();
    }
    @Override
    public Issue getIssueById(Integer id) {

        return issueRepository.findById(id)
                .orElseThrow(() ->
                    new IssueException(
                        "Issue not found with ID: " + id
                    )
                );
    }
    @Override
    public Issue updateIssue(
            Integer id,
            Issue issue) {

        Issue existing =
                getIssueById(id);

        existing.setProjectId(issue.getProjectId());
        existing.setAssignee(issue.getAssignee());
        existing.setDescription(issue.getDescription());
        existing.setSummary(issue.getSummary());
        existing.setPriority(issue.getPriority());
        existing.setStatus(issue.getStatus());
        existing.setCreatedBy(issue.getCreatedBy());
        existing.setSprint(issue.getSprint());
        existing.setStoryPoint(issue.getStoryPoint());
        existing.setTags(issue.getTags());
        existing.setType(issue.getType());

        existing.setLastUpdated(LocalDate.now());

        return issueRepository.save(existing);
    }

    @Override
    public List<Issue> getIssuesByProject(
            Integer projectId) {

        return issueRepository
                .findByProjectId(projectId);
    }

    @Override
    public List<Issue> getIssuesByAssignee(
            Integer assignee) {

        return issueRepository
                .findByAssignee(assignee);
    }

    @Override
    public List<Issue> getIssuesByOwner(Integer ownerId) {

        return issueRepository
                .findByCreatedBy(ownerId);
    }
}