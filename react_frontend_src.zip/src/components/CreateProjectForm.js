import { useContext, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { createProject } from '../services/projectService';

function CreateProjectForm() {
    const { user, isLoggedIn } = useContext(AuthContext);
    const navigate = useNavigate();

    const [form, setForm] = useState({
        projectName: '',
        startDate: '',
        endDate: ''
    });
    const [errors, setErrors] = useState({});
    const [serverError, setServerError] = useState('');

    const validate = () => {
        const next = {};

        if (!form.projectName.trim()) {
            next.projectName = 'Project name is required.';
        }

        if (form.startDate && form.endDate && form.endDate < form.startDate) {
            next.endDate = 'End date cannot be before start date.';
        }

        return next;
    };

    const handleChange = (event) => {
        const { name, value } = event.target;
        setForm((previous) => ({ ...previous, [name]: value }));
        setErrors((previous) => ({ ...previous, [name]: '' }));
    };

    const handleSubmit = async (event) => {
        event.preventDefault();

        const validationErrors = validate();
        setErrors(validationErrors);

        if (Object.keys(validationErrors).length > 0) {
            return;
        }

        try {
            await createProject({
                projectName: form.projectName.trim(),
                projectOwner: user.userId,
                startDate: form.startDate || null,
                endDate: form.endDate || null
            });

            navigate('/project-dashboard');
        } catch (error) {
            setServerError(
                error.response?.data?.message || 'Unable to create project.'
            );
        }
    };

    if (!isLoggedIn || Number(user?.role) !== 1) {
        return null;
    }

    return (
        <div className="case-form-page">
            <div className="case-form-card">
                <div className="case-title-bar">Issue Tracking System</div>
                <div className="p-4">
                    <h3>Create Project</h3>

                    {serverError && (
                        <div className="alert alert-danger">{serverError}</div>
                    )}

                    <form onSubmit={handleSubmit} noValidate>
                        <div className="mb-3">
                            <label className="form-label">Project Name</label>
                            <input
                                type="text"
                                name="projectName"
                                className={`form-control ${errors.projectName ? 'is-invalid' : ''}`}
                                value={form.projectName}
                                onChange={handleChange}
                                onBlur={() =>
                                    setErrors((previous) => ({
                                        ...previous,
                                        projectName: form.projectName.trim()
                                            ? ''
                                            : 'Project name is required.'
                                    }))
                                }
                            />
                            {errors.projectName && (
                                <div className="invalid-feedback">{errors.projectName}</div>
                            )}
                        </div>

                        <div className="row">
                            <div className="col-md-6 mb-3">
                                <label className="form-label">Start Date</label>
                                <input
                                    type="date"
                                    name="startDate"
                                    className="form-control"
                                    value={form.startDate}
                                    onChange={handleChange}
                                />
                            </div>

                            <div className="col-md-6 mb-3">
                                <label className="form-label">End Date</label>
                                <input
                                    type="date"
                                    name="endDate"
                                    className={`form-control ${errors.endDate ? 'is-invalid' : ''}`}
                                    value={form.endDate}
                                    onChange={handleChange}
                                />
                                {errors.endDate && (
                                    <div className="invalid-feedback">{errors.endDate}</div>
                                )}
                            </div>
                        </div>

                        <div className="d-flex gap-2">
                            <button type="submit" className="btn case-primary-btn">
                                Create
                            </button>
                            <button
                                type="button"
                                className="btn btn-secondary"
                                onClick={() => navigate('/project-dashboard')}
                            >
                                Reset
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default CreateProjectForm;
