import { useContext, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { getIssuesByUserId } from '../services/userService';

const statuses = [
    { value: 'OPEN', label: 'TO-DO' },
    { value: 'IN_PROGRESS', label: 'DEVELOPMENT' },
    { value: 'RESOLVED', label: 'TESTING' },
    { value: 'CLOSED', label: 'COMPLETED' }
];

function AssigneeDashboard() {
    const { user, isLoggedIn, ctxLogout } = useContext(AuthContext);
    const navigate = useNavigate();

    const [issues, setIssues] = useState([]);
    const [searchText, setSearchText] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        if (!isLoggedIn) {
            navigate('/login');
            return;
        }

        if (Number(user?.role) !== 2) {
            navigate('/project-dashboard');
            return;
        }

        const load = async () => {
            try {
                const data = await getIssuesByUserId(user.userId);
                setIssues(data);
            } catch (err) {
                setError(
                    err.response?.data?.message || 'Unable to load assigned issues.'
                );
            }
        };

        load();
    }, [isLoggedIn, navigate, user]);

    const visibleIssues = useMemo(() => {
        if (!searchText.trim()) return issues;

        try {
            const regex = new RegExp(searchText, 'i');
            return issues.filter(
                (issue) =>
                    regex.test(issue.summary || '') ||
                    regex.test(issue.description || '')
            );
        } catch {
            return [];
        }
    }, [issues, searchText]);

    if (!isLoggedIn || Number(user?.role) !== 2) {
        return null;
    }

    return (
        <div className="case-dashboard">
            <aside className="case-sidebar">
                <div className="profile-block">
                    <img
                        src={user.profile}
                        alt={user.name}
                        className="profile-image"
                    />
                    <h5>{user.name}</h5>
                    <small>{user.email}</small>
                </div>

                <div className="sidebar-stats single">
                    <div>
                        <strong>{issues.length}</strong>
                        <span>Issues Assigned</span>
                    </div>
                </div>

                <button
                    className="sidebar-link button-link"
                    onClick={() => navigate('/assignee-dashboard')}
                >
                    Issue Dashboard
                </button>

                <button
                    className="sidebar-logout"
                    onClick={() => {
                        ctxLogout();
                        navigate('/login');
                    }}
                >
                    Logout
                </button>
            </aside>

            <main className="case-main">
                <div className="case-header-row">
                    <input
                        className="form-control case-search"
                        placeholder="Search summary or description"
                        value={searchText}
                        onChange={(e) => setSearchText(e.target.value)}
                    />
                    <div className="case-app-name">Issue Tracking System</div>
                </div>

                {error && <div className="alert alert-danger mt-3">{error}</div>}

                <div className="status-board mt-4">
                    {statuses.map((status) => {
                        const statusIssues = visibleIssues.filter(
                            (issue) => issue.status === status
                        );

                        return (
                            <div className="status-column" key={status}>
                                <h5>{status.label}</h5>

                                {statusIssues.map((issue) => (
                                    <button
                                        className="issue-card"
                                        key={issue.id}
                                        onClick={() =>
                                            navigate(`/assignee-issue/${issue.id}`)
                                        }
                                    >
                                        <strong>#{issue.id}</strong>
                                        <span>{issue.summary}</span>
                                        <small>{issue.description}</small>
                                        <small>{issue.createdOn || '-'}</small>
                                        <div className="issue-assignee">
                                            <img src={user.profile} alt="" />
                                            <span>{user.name}</span>
                                        </div>
                                        <em>{issue.priority}</em>
                                    </button>
                                ))}
                            </div>
                        );
                    })}
                </div>
            </main>
        </div>
    );
}

export default AssigneeDashboard;
