import { useContext, useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { getIssuesByProject, getProjectsByOwner } from '../services/projectService';
import { getAllIssues } from '../services/issueService';
import { getAllUsers } from '../services/userService';

const statuses = [
    { value: 'OPEN', label: 'TO-DO' },
    { value: 'IN_PROGRESS', label: 'DEVELOPMENT' },
    { value: 'RESOLVED', label: 'TESTING' },
    { value: 'CLOSED', label: 'COMPLETED' }
];

function ProjectOwnerDashboard() {
    const { user, isLoggedIn, ctxLogout } = useContext(AuthContext);
    const navigate = useNavigate();

    const [projects, setProjects] = useState([]);
    const [selectedProject, setSelectedProject] = useState(null);
    const [issues, setIssues] = useState([]);
    const [createdIssueCount, setCreatedIssueCount] = useState(0);
    const [users, setUsers] = useState([]);
    const [searchText, setSearchText] = useState('');
    const [priority, setPriority] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        if (!isLoggedIn) {
            navigate('/login');
            return;
        }

        if (Number(user?.role) !== 1) {
            navigate('/assignee-dashboard');
            return;
        }

        const load = async () => {
            try {
                const [data, allIssues, userData] = await Promise.all([
                    getProjectsByOwner(user.userId),
                    getAllIssues(),
                    getAllUsers()
                ]);
                setUsers(userData);
                setProjects(data);
                setCreatedIssueCount(
                    allIssues.filter(
                        (issue) => Number(issue.createdBy) === Number(user.userId)
                    ).length
                );

                if (data.length > 0) {
                    setSelectedProject(data[0]);
                    const projectIssues = await getIssuesByProject(data[0].id);
                    setIssues(projectIssues);
                } else {
                    setSelectedProject(null);
                    setIssues([]);
                }
            } catch (err) {
                setError(
                    err.response?.data?.message || 'Unable to load project dashboard.'
                );
            }
        };

        load();
    }, [isLoggedIn, navigate, user]);

    const selectProject = async (project) => {
        setSelectedProject(project);
        setError('');

        try {
            const data = await getIssuesByProject(project.id);
            setIssues(data);
        } catch (err) {
            setError(
                err.response?.data?.message || 'Unable to load project issues.'
            );
        }
    };

    const visibleIssues = useMemo(() => {
        let result = issues;

        if (priority) {
            result = result.filter((issue) => issue.priority === priority);
        }

        if (searchText.trim()) {
            try {
                const regex = new RegExp(searchText, 'i');
                result = result.filter(
                    (issue) =>
                        regex.test(issue.summary || '') ||
                        regex.test(issue.description || '')
                );
            } catch {
                result = [];
            }
        }

        return result;
    }, [issues, priority, searchText]);

    if (!isLoggedIn || Number(user?.role) !== 1) {
        return null;
    }

    return (
        <div className="case-dashboard">
            <aside className="case-sidebar">
                <div className="profile-block">
                    <img
                        src={user.profile}
                        alt={user.name}
                        className="profile-image"
                    />
                    <h5>{user.name}</h5>
                    <small>{user.email}</small>
                </div>

                <div className="sidebar-stats">
                    <div>
                        <strong>{projects.length}</strong>
                        <span>Projects Created</span>
                    </div>
                    <div>
                        <strong>{issues.length}</strong>
                        <span>Issues Created</span>
                    </div>
                </div>

                <Link to="/project-dashboard" className="sidebar-link">
                    Project Dashboard
                </Link>
                <Link to="/create-project" className="sidebar-link">
                    Create Project
                </Link>
                <Link to="/create-issue" className="sidebar-link">
                    Create Issue
                </Link>

                <button
                    className="sidebar-logout"
                    onClick={() => {
                        ctxLogout();
                        navigate('/login');
                    }}
                >
                    Logout
                </button>
            </aside>

            <main className="case-main">
                <div className="case-header-row">
                    <input
                        className="form-control case-search"
                        placeholder="Search summary or description"
                        value={searchText}
                        onChange={(e) => setSearchText(e.target.value)}
                    />
                    <div className="case-app-name">Issue Tracking System</div>
                </div>

                {error && <div className="alert alert-danger mt-3">{error}</div>}

                {projects.length === 0 ? (
                    <div className="empty-state">
                        <h4>No Projects Available</h4>
                        <Link to="/create-project" className="btn case-primary-btn">
                            Create Project
                        </Link>
                    </div>
                ) : (
                    <>
                        <div className="project-selector">
                            {projects.map((project) => (
                                <button
                                    key={project.id}
                                    className={`btn ${selectedProject?.id === project.id ? 'case-primary-btn' : 'btn-outline-secondary'}`}
                                    onClick={() => selectProject(project)}
                                >
                                    {project.projectName}
                                </button>
                            ))}
                        </div>

                        {selectedProject && (
                            <>
                                <div className="project-summary">
                                    <div>
                                        <strong>Project Name</strong>
                                        <span>{selectedProject.projectName}</span>
                                    </div>
                                    <div>
                                        <strong>Project Owner Name</strong>
                                        <span>{user.name}</span>
                                    </div>
                                    <div>
                                        <strong>Start Date</strong>
                                        <span>{selectedProject.startDate || '-'}</span>
                                    </div>
                                    <div>
                                        <strong>End Date</strong>
                                        <span>{selectedProject.endDate || '-'}</span>
                                    </div>
                                    <div>
                                        <label htmlFor="priorityFilter">
                                            Filter by Priority
                                        </label>
                                        <select
                                            id="priorityFilter"
                                            className="form-select"
                                            value={priority}
                                            onChange={(e) => setPriority(e.target.value)}
                                        >
                                            <option value="">All</option>
                                            <option value="LOW">LOW</option>
                                            <option value="MEDIUM">MEDIUM</option>
                                            <option value="HIGH">HIGH</option>
                                        </select>
                                    </div>
                                </div>

                                <div className="status-board">
                                    {statuses.map((status) => {
                                        const statusIssues = visibleIssues.filter(
                                            (issue) => issue.status === status
                                        );

                                        return (
                                            <div className="status-column" key={status}>
                                                <h5>{status.label}</h5>
                                                {statusIssues.map((issue) => (
                                                    <button
                                                        className="issue-card"
                                                        key={issue.id}
                                                        onClick={() =>
                                                            navigate(`/issue/${issue.id}`)
                                                        }
                                                    >
                                                        <strong>#{issue.id}</strong>
                                                        <span>{issue.summary}</span>
                                                        <small>{issue.description}</small>
                                        <small>{issue.createdOn || '-'}</small>
                                                        <div className="issue-assignee">
                                                            {users.find(
                                                                (item) =>
                                                                    Number(item.userId) ===
                                                                    Number(issue.assignee)
                                                            )?.profile && (
                                                                <img
                                                                    src={
                                                                        users.find(
                                                                            (item) =>
                                                                                Number(item.userId) ===
                                                                                Number(issue.assignee)
                                                                        ).profile
                                                                    }
                                                                    alt=""
                                                                />
                                                            )}
                                                            <span>
                                                                {users.find(
                                                                    (item) =>
                                                                        Number(item.userId) ===
                                                                        Number(issue.assignee)
                                                                )?.name || issue.assignee}
                                                            </span>
                                                        </div>
                                                        <em>{issue.priority}</em>
                                                    </button>
                                                ))}
                                            </div>
                                        );
                                    })}
                                </div>
                            </>
                        )}
                    </>
                )}
            </main>
        </div>
    );
}

export default ProjectOwnerDashboard;
