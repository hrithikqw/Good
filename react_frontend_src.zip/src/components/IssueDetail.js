import { useContext, useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { getIssueById } from '../services/issueService';
import { getProjectById } from '../services/projectService';
import { getUserById } from '../services/userService';

function IssueDetail() {
    const { issueId } = useParams();
    const { user, isLoggedIn } = useContext(AuthContext);
    const navigate = useNavigate();

    const [issue, setIssue] = useState(null);
    const [project, setProject] = useState(null);
    const [assignee, setAssignee] = useState(null);
    const [error, setError] = useState('');

    useEffect(() => {
        if (!isLoggedIn) {
            navigate('/login');
            return;
        }

        if (Number(user?.role) !== 1) {
            navigate('/assignee-dashboard');
            return;
        }

        const load = async () => {
            try {
                const issueData = await getIssueById(issueId);
                setIssue(issueData);

                const [projectData, assigneeData] = await Promise.all([
                    getProjectById(issueData.projectId),
                    getUserById(issueData.assignee)
                ]);

                setProject(projectData);
                setAssignee(assigneeData);
            } catch (err) {
                setError(
                    err.response?.data?.message || 'Unable to load issue details.'
                );
            }
        };

        load();
    }, [issueId, isLoggedIn, navigate, user]);

    if (!isLoggedIn) {
        return null;
    }

    if (error) {
        return <div className="alert alert-danger m-4">{error}</div>;
    }

    if (!issue) {
        return <div className="text-center p-5">Loading...</div>;
    }

    return (
        <div className="case-form-page">
            <div className="case-form-card wide">
                <div className="case-title-bar">Issue Tracking System</div>
                <div className="p-4">
                    <div className="d-flex justify-content-between align-items-center">
                        <div>
                            <small>
                                {project?.projectName || 'Project'} / Issue Details
                            </small>
                            <h2>{issue.summary}</h2>
                        </div>
                        <button
                            className="btn case-primary-btn"
                            onClick={() => navigate(`/issue/${issue.id}/edit`)}
                        >
                            Edit Issue
                        </button>
                    </div>

                    <div className="mt-4">
                        <h5>Description</h5>
                        <p>{issue.description || '-'}</p>
                    </div>

                    <div className="row issue-details-grid">
                        <div className="col-md-6">
                            <p><strong>Type:</strong> {issue.type}</p>
                            <p><strong>Tags:</strong> {issue.tags || '-'}</p>
                            <p><strong>Story Points:</strong> {issue.storyPoint}</p>
                            <p><strong>Sprint:</strong> {issue.sprint}</p>
                        </div>
                        <div className="col-md-6">
                            <p><strong>Status:</strong> {issue.status}</p>
                            <p><strong>Priority:</strong> {issue.priority}</p>
                            <p>
                                <strong>Assignee:</strong>{' '}
                                {assignee?.profile && (
                                    <img
                                        src={assignee.profile}
                                        alt={assignee.name}
                                        className="detail-profile-image"
                                    />
                                )}
                                {assignee?.name || issue.assignee}
                            </p>
                            <p><strong>Created On:</strong> {issue.createdOn || '-'}</p>
                            <p><strong>Last Updated:</strong> {issue.lastUpdated || '-'}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default IssueDetail;
