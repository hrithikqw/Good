import axios from 'axios';

export const USER_API_BASE_URL = 'http://localhost:8085/api/users';

export async function registerUser(user) {
    const response = await axios.post(USER_API_BASE_URL, {
        name: user.name,
        email: user.email,
        password: user.password,
        profile: user.profile,
        role: Number(user.role)
    });

    return response.data;
}

export async function getAllUsers() {
    const response = await axios.get(`${USER_API_BASE_URL}/all`);
    return response.data;
}

export async function getUserById(userId) {
    const response = await axios.get(`${USER_API_BASE_URL}/${userId}`);
    return response.data;
}

export async function login(email, password, role) {
    const response = await axios.post(`${USER_API_BASE_URL}/login`, {
        email,
        password,
        role: Number(role)
    });

    return response.data;
}

export async function getIssuesByUserId(userId) {
    const response = await axios.get(`${USER_API_BASE_URL}/${userId}/issues`);
    return response.data;
}

export async function getIssuesByUsername(username) {
    const response = await axios.get(
        `${USER_API_BASE_URL}/username/${encodeURIComponent(username)}/issues`
    );
    return response.data;
}
