import axios from 'axios';

export const ISSUE_API_BASE_URL = 'http://localhost:8085/api/issues';

export async function createIssue(issue) {
    const response = await axios.post(ISSUE_API_BASE_URL, issue);
    return response.data;
}

export async function getAllIssues() {
    const response = await axios.get(ISSUE_API_BASE_URL);
    return response.data;
}

export async function getIssueById(issueId) {
    const response = await axios.get(`${ISSUE_API_BASE_URL}/${issueId}`);
    return response.data;
}

export async function updateIssue(issueId, issue) {
    const response = await axios.put(
        `${ISSUE_API_BASE_URL}/${issueId}`,
        issue
    );
    return response.data;
}

export async function getIssuesByProject(issueProjectId) {
    const response = await axios.get(
        `${ISSUE_API_BASE_URL}/project/${issueProjectId}`
    );
    return response.data;
}

export async function getIssuesByAssignee(assigneeId) {
    const response = await axios.get(
        `${ISSUE_API_BASE_URL}/assignee/${assigneeId}`
    );
    return response.data;
}
