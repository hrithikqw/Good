export default class Issue {
  constructor(
    id,
    projectId,
    assignee,
    createdOn,
    lastUpdated,
    description,
    summary,
    priority,
    status,
    createdBy,
    sprint,
    storyPoint,
    tags,
    type
  ) {
    this.id = id;
    this.projectId = projectId;
    this.assignee = assignee;
    this.createdOn = createdOn;
    this.lastUpdated = lastUpdated;
    this.description = description;
    this.summary = summary;
    this.priority = priority;
    this.status = status;
    this.createdBy = createdBy;
    this.sprint = sprint;
    this.storyPoint = storyPoint;
    this.tags = tags;
    this.type = type;
  }
}
