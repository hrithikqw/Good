import axios from "axios";

export const USER_API_BASE_URL = "http://localhost:8085/api/users";

export const addUser = async (user) => {
  const response = await axios.post(USER_API_BASE_URL, {
    name: user.name,
    email: user.email,
    password: user.password,
    role: Number(user.role)
  });
  return response.data;
};

export const getAllUsers = async () => {
  const response = await axios.get(USER_API_BASE_URL);
  return response.data;
};

export const getUserById = async (userId) => {
  const response = await axios.get(`${USER_API_BASE_URL}/${userId}`);
  return response.data;
};

export const login = async (email, password) => {
  const response = await axios.post(`${USER_API_BASE_URL}/login`, {
    email,
    password
  });
  return response.data;
};

export const getIssuesByUserId = async (userId) => {
  const response = await axios.get(`${USER_API_BASE_URL}/${userId}/issues`);
  return response.data;
};

export const getIssuesByUsername = async (username) => {
  const response = await axios.get(
    `${USER_API_BASE_URL}/username/${encodeURIComponent(username)}/issues`
  );
  return response.data;
};
