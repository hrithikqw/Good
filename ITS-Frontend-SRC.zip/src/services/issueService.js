import axios from "axios";

export const ISSUE_API_BASE_URL = "http://localhost:8085/api/issues";

export const addIssue = async (issue) => {
  const response = await axios.post(ISSUE_API_BASE_URL, issue);
  return response.data;
};

export const getAllIssues = async () => {
  const response = await axios.get(ISSUE_API_BASE_URL);
  return response.data;
};

export const getIssueById = async (id) => {
  const response = await axios.get(`${ISSUE_API_BASE_URL}/${id}`);
  return response.data;
};

export const updateIssue = async (id, issue) => {
  const response = await axios.put(`${ISSUE_API_BASE_URL}/${id}`, issue);
  return response.data;
};

export const getIssuesByProject = async (projectId) => {
  const response = await axios.get(
    `${ISSUE_API_BASE_URL}/project/${projectId}`
  );
  return response.data;
};

export const getIssuesByAssignee = async (assignee) => {
  const response = await axios.get(
    `${ISSUE_API_BASE_URL}/assignee/${assignee}`
  );
  return response.data;
};
