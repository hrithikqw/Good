import axios from "axios";

export const PROJECT_API_BASE_URL = "http://localhost:8085/api/projects";

export const addProject = async (project) => {
  const response = await axios.post(PROJECT_API_BASE_URL, project);
  return response.data;
};

export const getAllProjects = async () => {
  const response = await axios.get(PROJECT_API_BASE_URL);
  return response.data;
};

export const getProjectById = async (projectId) => {
  const response = await axios.get(`${PROJECT_API_BASE_URL}/${projectId}`);
  return response.data;
};

export const updateProject = async (projectId, project) => {
  const response = await axios.put(
    `${PROJECT_API_BASE_URL}/${projectId}`,
    project
  );
  return response.data;
};

export const deleteProject = async (projectId) => {
  const response = await axios.delete(
    `${PROJECT_API_BASE_URL}/${projectId}`
  );
  return response.data;
};

export const getProjectsByOwner = async (ownerId) => {
  const response = await axios.get(
    `${PROJECT_API_BASE_URL}/owner/${ownerId}`
  );
  return response.data;
};

export const getIssuesByProject = async (projectId) => {
  const response = await axios.get(
    `${PROJECT_API_BASE_URL}/${projectId}/issues`
  );
  return response.data;
};

export const getIssuesByProjectName = async (projectName) => {
  const response = await axios.get(
    `${PROJECT_API_BASE_URL}/projectName/${encodeURIComponent(projectName)}/issues`
  );
  return response.data;
};
