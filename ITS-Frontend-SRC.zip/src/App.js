import './App.css';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from 'react-router-dom';
import { useContext } from 'react';
import { AuthContext } from './context/AuthContext';
import UserLoginForm from './components/UserLoginForm';
import UserSignupForm from './components/UserSignupForm';
import UserList from './components/UserList';
import ProjectList from './components/ProjectList';
import ProjectForm from './components/ProjectForm';
import IssueList from './components/IssueList';
import IssueForm from './components/IssueForm';

function NavBar() {
  const { isLoggedIn, user, ctxLogout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    ctxLogout();
    navigate('/login');
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
      <div className="container-fluid">
        <Link className="navbar-brand" to="/">Issue Tracking System</Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="nav-item">
              <Link className="nav-link" to="/">Projects</Link>
            </li>

            {isLoggedIn && (
              <li className="nav-item">
                <Link className="nav-link" to="/issues">Issues</Link>
              </li>
            )}

            {isLoggedIn && (
              <li className="nav-item">
                <Link className="nav-link" to="/users">Users</Link>
              </li>
            )}

            {!isLoggedIn && (
              <>
                <li className="nav-item">
                  <Link className="nav-link" to="/login">Login</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/signup">Signup</Link>
                </li>
              </>
            )}

            {isLoggedIn && (
              <li className="nav-item">
                <button className="nav-link btn btn-link text-white" onClick={handleLogout}>
                  Logout
                </button>
              </li>
            )}
          </ul>

          {isLoggedIn && user && (
            <span className="navbar-text me-3">
              {user.name} (Role {user.role})
            </span>
          )}
        </div>
      </div>
    </nav>
  );
}

function App() {
  return (
    <div className="App">
      <Router>
        <NavBar />
        <Routes>
          <Route path="/" element={<ProjectList />} />
          <Route path="/login" element={<UserLoginForm />} />
          <Route path="/signup" element={<UserSignupForm />} />
          <Route path="/users" element={<UserList />} />
          <Route path="/projects/new" element={<ProjectForm />} />
          <Route path="/projects/:projectId/edit" element={<ProjectForm />} />
          <Route path="/issues" element={<IssueList />} />
          <Route path="/issues/new" element={<IssueForm />} />
          <Route path="/issues/:issueId/edit" element={<IssueForm />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
