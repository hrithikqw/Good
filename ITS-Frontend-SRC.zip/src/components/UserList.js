import { useEffect, useState } from "react";
import { getAllUsers, getIssuesByUserId, getIssuesByUsername } from "../services/userService";

function UserList() {
  const [users, setUsers] = useState([]);
  const [issues, setIssues] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [username, setUsername] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    const loadUsers = async () => {
      try {
        setUsers(await getAllUsers());
      } catch (err) {
        setError(err.response?.data?.message || "Unable to load users");
      }
    };
    loadUsers();
  }, []);

  const viewUserIssues = async (user) => {
    try {
      setError("");
      setSelectedUser(user);
      setIssues(await getIssuesByUserId(user.userId));
    } catch (err) {
      setError(err.response?.data?.message || "Unable to load user issues");
    }
  };

  const searchByUsername = async (e) => {
    e.preventDefault();
    if (!username.trim()) return;

    try {
      setError("");
      setSelectedUser(null);
      setIssues(await getIssuesByUsername(username.trim()));
    } catch (err) {
      setError(err.response?.data?.message || "Unable to load user issues");
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="mb-4">Users</h2>

      {error && <div className="alert alert-danger">{error}</div>}

      <form className="row g-2 mb-4" onSubmit={searchByUsername}>
        <div className="col-md-10">
          <input
            className="form-control"
            placeholder="Search issues by username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div className="col-md-2">
          <button className="btn btn-primary w-100" type="submit">
            Search
          </button>
        </div>
      </form>

      <table className="table table-bordered table-hover align-middle text-center">
        <thead className="table-primary">
          <tr>
            <th>User ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Issues</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.userId}>
              <td>{user.userId}</td>
              <td>{user.name}</td>
              <td>{user.email}</td>
              <td>{user.role}</td>
              <td>
                <button
                  className="btn btn-sm btn-info"
                  onClick={() => viewUserIssues(user)}
                >
                  View Issues
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {(selectedUser || issues.length > 0) && (
        <div className="mt-4">
          <h4>
            {selectedUser
              ? `Issues for ${selectedUser.name}`
              : `Issues for ${username}`}
          </h4>
          <table className="table table-striped table-bordered">
            <thead>
              <tr>
                <th>ID</th>
                <th>Project</th>
                <th>Summary</th>
                <th>Priority</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {issues.map((issue) => (
                <tr key={issue.id}>
                  <td>{issue.id}</td>
                  <td>{issue.projectId}</td>
                  <td>{issue.summary}</td>
                  <td>{issue.priority}</td>
                  <td>{issue.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default UserList;
