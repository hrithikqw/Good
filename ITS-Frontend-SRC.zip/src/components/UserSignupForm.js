import { useState } from "react";
import { addUser } from "../services/userService";
import User from "../models/User";

function UserSignupForm() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    role: ""
  });
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage("");
    setError("");

    try {
      const user = new User(
        "",
        form.name,
        form.email,
        form.password,
        form.role
      );
      const result = await addUser(user);
      setMessage(`User created successfully. User ID: ${result.userId}`);
      setForm({ name: "", email: "", password: "", role: "" });
    } catch (err) {
      setError(err.response?.data?.message || "Unable to create user");
    }
  };

  return (
    <div className="container-fluid min-vh-100 d-flex justify-content-center align-items-center bg-light">
      <div className="col-md-6 col-lg-5">
        <div className="card shadow-lg border-0">
          <div className="card-header bg-primary text-white text-center py-3">
            <h2 className="mb-0">Register User</h2>
          </div>
          <div className="card-body p-4">
            {message && <div className="alert alert-success">{message}</div>}
            {error && <div className="alert alert-danger">{error}</div>}

            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label className="form-label">Name:</label>
                <input
                  type="text"
                  name="name"
                  className="form-control"
                  value={form.name}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Email:</label>
                <input
                  type="email"
                  name="email"
                  className="form-control"
                  value={form.email}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Password:</label>
                <input
                  type="password"
                  name="password"
                  className="form-control"
                  value={form.password}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Role:</label>
                <select
                  name="role"
                  className="form-select"
                  value={form.role}
                  onChange={handleChange}
                  required
                >
                  <option value="">Select Role</option>
                  <option value="1">Project Owner</option>
                  <option value="2">Assignee</option>
                </select>
              </div>

              <button type="submit" className="btn btn-primary w-100">
                Register
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default UserSignupForm;
