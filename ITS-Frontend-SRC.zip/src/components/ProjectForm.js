import { useContext, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { addProject, getProjectById, updateProject } from "../services/projectService";

function ProjectForm() {
  const { user } = useContext(AuthContext);
  const { projectId } = useParams();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    projectName: "",
    projectOwner: "",
    startDate: "",
    endDate: ""
  });
  const [error, setError] = useState("");

  useEffect(() => {
    const loadProject = async () => {
      if (!projectId) {
        setForm((current) => ({
          ...current,
          projectOwner: user?.userId || ""
        }));
        return;
      }

      try {
        const project = await getProjectById(projectId);
        setForm({
          projectName: project.projectName || "",
          projectOwner: project.projectOwner || "",
          startDate: project.startDate || "",
          endDate: project.endDate || ""
        });
      } catch (err) {
        setError(err.response?.data?.message || "Unable to load project");
      }
    };

    loadProject();
  }, [projectId, user]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      const project = {
        projectName: form.projectName,
        projectOwner: Number(form.projectOwner),
        startDate: form.startDate || null,
        endDate: form.endDate || null
      };

      if (projectId) {
        await updateProject(projectId, project);
      } else {
        await addProject(project);
      }

      navigate("/");
    } catch (err) {
      setError(err.response?.data?.message || "Unable to save project");
    }
  };

  return (
    <div className="container mt-5 d-flex justify-content-center">
      <div className="col-md-6">
        <div className="card shadow border-0">
          <div className="card-header bg-primary text-white text-center">
            <h2 className="mb-0">{projectId ? "Update Project" : "Add Project"}</h2>
          </div>
          <div className="card-body p-4">
            {error && <div className="alert alert-danger">{error}</div>}

            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label className="form-label">Project Name:</label>
                <input
                  type="text"
                  name="projectName"
                  className="form-control"
                  value={form.projectName}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Project Owner ID:</label>
                <input
                  type="number"
                  name="projectOwner"
                  className="form-control"
                  value={form.projectOwner}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Start Date:</label>
                <input
                  type="date"
                  name="startDate"
                  className="form-control"
                  value={form.startDate}
                  onChange={handleChange}
                />
              </div>

              <div className="mb-3">
                <label className="form-label">End Date:</label>
                <input
                  type="date"
                  name="endDate"
                  className="form-control"
                  value={form.endDate}
                  onChange={handleChange}
                />
              </div>

              <button type="submit" className="btn btn-primary w-100">
                {projectId ? "Update Project" : "Create Project"}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProjectForm;
