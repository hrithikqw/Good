import { useContext, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import {
  getAllIssues,
  getIssuesByAssignee,
  getIssuesByProject
} from "../services/issueService";

function IssueList() {
  const { isLoggedIn, user } = useContext(AuthContext);
  const [issues, setIssues] = useState([]);
  const [projectId, setProjectId] = useState("");
  const [error, setError] = useState("");

  const isOwner = user && Number(user.role) === 1;

  const loadIssues = async () => {
    if (!isLoggedIn) return;

    try {
      setError("");
      const data = isOwner
        ? await getAllIssues()
        : await getIssuesByAssignee(user.userId);
      setIssues(data);
    } catch (err) {
      setError(err.response?.data?.message || "Unable to load issues");
    }
  };

  useEffect(() => {
    loadIssues();
  }, [isLoggedIn, user]);

  const searchByProject = async (e) => {
    e.preventDefault();
    if (!projectId) return;

    try {
      setError("");
      setIssues(await getIssuesByProject(projectId));
    } catch (err) {
      setError(err.response?.data?.message || "Unable to load project issues");
    }
  };

  return (
    <div className="container mt-5">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>{isOwner ? "All Issues" : "Assigned Issues"}</h2>

        {isLoggedIn && isOwner && (
          <Link to="/issues/new" className="btn btn-primary">
            Add Issue
          </Link>
        )}
      </div>

      {error && <div className="alert alert-danger">{error}</div>}

      <form className="row g-2 mb-4" onSubmit={searchByProject}>
        <div className="col-md-10">
          <input
            type="number"
            className="form-control"
            placeholder="Project ID"
            value={projectId}
            onChange={(e) => setProjectId(e.target.value)}
          />
        </div>
        <div className="col-md-2">
          <button className="btn btn-primary w-100" type="submit">
            Search
          </button>
        </div>
      </form>

      <table className="table table-bordered table-hover align-middle text-center">
        <thead className="table-primary">
          <tr>
            <th>ID</th>
            <th>Project</th>
            <th>Assignee</th>
            <th>Summary</th>
            <th>Priority</th>
            <th>Status</th>
            <th>Type</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {issues.map((issue) => (
            <tr key={issue.id}>
              <td>{issue.id}</td>
              <td>{issue.projectId}</td>
              <td>{issue.assignee}</td>
              <td>{issue.summary}</td>
              <td>{issue.priority}</td>
              <td>{issue.status}</td>
              <td>{issue.type}</td>
              <td>
                {isLoggedIn && (
                  <Link
                    to={`/issues/${issue.id}/edit`}
                    className="btn btn-warning btn-sm"
                  >
                    Update
                  </Link>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default IssueList;
