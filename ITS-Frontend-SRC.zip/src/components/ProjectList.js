import { useContext, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import {
  deleteProject,
  getAllProjects,
  getIssuesByProject,
  getIssuesByProjectName,
  getProjectsByOwner
} from "../services/projectService";

function ProjectList() {
  const { isLoggedIn, user } = useContext(AuthContext);
  const [projects, setProjects] = useState([]);
  const [issues, setIssues] = useState([]);
  const [projectName, setProjectName] = useState("");
  const [selectedProject, setSelectedProject] = useState(null);
  const [error, setError] = useState("");

  const isOwner = user && Number(user.role) === 1;

  const loadProjects = async () => {
    try {
      setError("");
      const data = isOwner
        ? await getProjectsByOwner(user.userId)
        : await getAllProjects();
      setProjects(data);
    } catch (err) {
      setError(err.response?.data?.message || "Unable to load projects");
    }
  };

  useEffect(() => {
    loadProjects();
  }, [isOwner, user]);

  const handleDelete = async (projectId) => {
    if (!window.confirm("Are you sure you want to delete this project?")) {
      return;
    }

    try {
      await deleteProject(projectId);
      await loadProjects();
    } catch (err) {
      setError(err.response?.data?.message || "Unable to delete project");
    }
  };

  const viewIssues = async (project) => {
    try {
      setError("");
      setSelectedProject(project);
      setIssues(await getIssuesByProject(project.id));
    } catch (err) {
      setError(err.response?.data?.message || "Unable to load project issues");
    }
  };

  const searchByName = async (e) => {
    e.preventDefault();
    if (!projectName.trim()) return;

    try {
      setError("");
      setSelectedProject(null);
      setIssues(await getIssuesByProjectName(projectName.trim()));
    } catch (err) {
      setError(err.response?.data?.message || "Unable to load project issues");
    }
  };

  return (
    <div className="container mt-5">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>Projects</h2>
        {isLoggedIn && isOwner && (
          <Link to="/projects/new" className="btn btn-primary">
            Add Project
          </Link>
        )}
      </div>

      {error && <div className="alert alert-danger">{error}</div>}

      <form className="row g-2 mb-4" onSubmit={searchByName}>
        <div className="col-md-10">
          <input
            className="form-control"
            placeholder="Search issues by project name"
            value={projectName}
            onChange={(e) => setProjectName(e.target.value)}
          />
        </div>
        <div className="col-md-2">
          <button className="btn btn-primary w-100" type="submit">
            Search
          </button>
        </div>
      </form>

      <table className="table table-bordered table-hover align-middle text-center">
        <thead className="table-primary">
          <tr>
            <th>ID</th>
            <th>Project Name</th>
            <th>Owner</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {projects.map((project) => (
            <tr key={project.id}>
              <td>{project.id}</td>
              <td>{project.projectName}</td>
              <td>{project.projectOwner}</td>
              <td>{project.startDate}</td>
              <td>{project.endDate}</td>
              <td>
                <button
                  className="btn btn-info btn-sm me-2"
                  onClick={() => viewIssues(project)}
                >
                  Issues
                </button>

                {isOwner && Number(project.projectOwner) === Number(user.userId) && (
                  <>
                    <Link
                      to={`/projects/${project.id}/edit`}
                      className="btn btn-warning btn-sm me-2"
                    >
                      Update
                    </Link>
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() => handleDelete(project.id)}
                    >
                      Delete
                    </button>
                  </>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {selectedProject && (
        <div className="mt-4">
          <h4>Issues for {selectedProject.projectName}</h4>
          <table className="table table-striped table-bordered">
            <thead>
              <tr>
                <th>ID</th>
                <th>Assignee</th>
                <th>Summary</th>
                <th>Priority</th>
                <th>Status</th>
                <th>Type</th>
              </tr>
            </thead>
            <tbody>
              {issues.map((issue) => (
                <tr key={issue.id}>
                  <td>{issue.id}</td>
                  <td>{issue.assignee}</td>
                  <td>{issue.summary}</td>
                  <td>{issue.priority}</td>
                  <td>{issue.status}</td>
                  <td>{issue.type}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default ProjectList;
