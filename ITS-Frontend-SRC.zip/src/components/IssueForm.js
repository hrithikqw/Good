import { useContext, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { getAllUsers } from "../services/userService";
import { addIssue, getIssueById, updateIssue } from "../services/issueService";

function IssueForm() {
  const { user } = useContext(AuthContext);
  const { issueId } = useParams();
  const navigate = useNavigate();

  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({
    projectId: "",
    assignee: "",
    createdOn: "",
    description: "",
    summary: "",
    priority: "",
    status: "",
    createdBy: "",
    sprint: "",
    storyPoint: "",
    tags: "",
    type: ""
  });
  const [error, setError] = useState("");

  useEffect(() => {
    const loadData = async () => {
      try {
        setUsers(await getAllUsers());

        if (issueId) {
          const issue = await getIssueById(issueId);
          setForm({
            projectId: issue.projectId || "",
            assignee: issue.assignee || "",
            createdOn: issue.createdOn || "",
            description: issue.description || "",
            summary: issue.summary || "",
            priority: issue.priority || "",
            status: issue.status || "",
            createdBy: issue.createdBy || "",
            sprint: issue.sprint || "",
            storyPoint: issue.storyPoint || "",
            tags: issue.tags || "",
            type: issue.type || ""
          });
        } else {
          setForm((current) => ({
            ...current,
            createdBy: user?.userId || "",
            status: current.status || "Open"
          }));
        }
      } catch (err) {
        setError(err.response?.data?.message || "Unable to load issue data");
      }
    };

    loadData();
  }, [issueId, user]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      const issue = {
        projectId: Number(form.projectId),
        assignee: form.assignee ? Number(form.assignee) : null,
        createdOn: form.createdOn || null,
        description: form.description,
        summary: form.summary,
        priority: form.priority,
        status: form.status,
        createdBy: form.createdBy ? Number(form.createdBy) : null,
        sprint: form.sprint,
        storyPoint: form.storyPoint ? Number(form.storyPoint) : null,
        tags: form.tags,
        type: form.type
      };

      if (issueId) {
        await updateIssue(issueId, issue);
      } else {
        await addIssue(issue);
      }

      navigate("/issues");
    } catch (err) {
      setError(err.response?.data?.message || "Unable to save issue");
    }
  };

  if (!issueId && Number(user?.role) !== 1) {
    return (
      <div className="container mt-5">
        <div className="alert alert-danger">Only a Project Owner can create an issue.</div>
      </div>
    );
  }

  return (
    <div className="container mt-5 d-flex justify-content-center">
      <div className="col-md-7">
        <div className="card shadow border-0">
          <div className="card-header bg-primary text-white text-center">
            <h2 className="mb-0">{issueId ? "Update Issue" : "Add Issue"}</h2>
          </div>

          <div className="card-body p-4">
            {error && <div className="alert alert-danger">{error}</div>}

            <form onSubmit={handleSubmit}>
              <div className="row">
                <div className="col-md-6 mb-3">
                  <label className="form-label">Project ID:</label>
                  <input
                    type="number"
                    name="projectId"
                    className="form-control"
                    value={form.projectId}
                    onChange={handleChange}
                    required
                    readOnly={!!issueId && Number(user?.role) !== 1}
                  />
                </div>

                <div className="col-md-6 mb-3">
                  <label className="form-label">Assignee:</label>
                  <select
                    name="assignee"
                    className="form-select"
                    value={form.assignee}
                    onChange={handleChange}
                    disabled={!!issueId && Number(user?.role) !== 1}
                  >
                    <option value="">Select Assignee</option>
                    {users.map((item) => (
                      <option key={item.userId} value={item.userId}>
                        {item.name} (ID: {item.userId})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="col-md-6 mb-3">
                  <label className="form-label">Summary:</label>
                  <input
                    type="text"
                    name="summary"
                    className="form-control"
                    value={form.summary}
                    onChange={handleChange}
                    readOnly={!!issueId && Number(user?.role) !== 1}
                    required
                  />
                </div>

                <div className="col-md-6 mb-3">
                  <label className="form-label">Priority:</label>
                  <input
                    type="text"
                    name="priority"
                    className="form-control"
                    value={form.priority}
                    onChange={handleChange}
                    readOnly={!!issueId && Number(user?.role) !== 1}
                  />
                </div>

                <div className="col-md-6 mb-3">
                  <label className="form-label">Status:</label>
                  <input
                    type="text"
                    name="status"
                    className="form-control"
                    value={form.status}
                    onChange={handleChange}
                  />
                </div>

                <div className="col-md-6 mb-3">
                  <label className="form-label">Type:</label>
                  <input
                    type="text"
                    name="type"
                    className="form-control"
                    value={form.type}
                    onChange={handleChange}
                    readOnly={!!issueId && Number(user?.role) !== 1}
                  />
                </div>

                <div className="col-md-6 mb-3">
                  <label className="form-label">Created By:</label>
                  <input
                    type="number"
                    name="createdBy"
                    className="form-control"
                    value={form.createdBy}
                    onChange={handleChange}
                    readOnly={!!issueId && Number(user?.role) !== 1}
                  />
                </div>

                <div className="col-md-6 mb-3">
                  <label className="form-label">Created On:</label>
                  <input
                    type="date"
                    name="createdOn"
                    className="form-control"
                    value={form.createdOn}
                    onChange={handleChange}
                    readOnly={!!issueId && Number(user?.role) !== 1}
                    readOnly={!!issueId && Number(user?.role) !== 1}
                  />
                </div>

                <div className="col-md-6 mb-3">
                  <label className="form-label">Sprint:</label>
                  <input
                    type="text"
                    name="sprint"
                    className="form-control"
                    value={form.sprint}
                    onChange={handleChange}
                    readOnly={!!issueId && Number(user?.role) !== 1}
                  />
                </div>

                <div className="col-md-6 mb-3">
                  <label className="form-label">Story Point:</label>
                  <input
                    type="number"
                    name="storyPoint"
                    className="form-control"
                    value={form.storyPoint}
                    onChange={handleChange}
                    readOnly={!!issueId && Number(user?.role) !== 1}
                  />
                </div>

                <div className="col-12 mb-3">
                  <label className="form-label">Tags:</label>
                  <input
                    type="text"
                    name="tags"
                    className="form-control"
                    value={form.tags}
                    onChange={handleChange}
                    readOnly={!!issueId && Number(user?.role) !== 1}
                  />
                </div>

                <div className="col-12 mb-3">
                  <label className="form-label">Description:</label>
                  <textarea
                    name="description"
                    className="form-control"
                    rows="3"
                    value={form.description}
                    onChange={handleChange}
                    readOnly={!!issueId && Number(user?.role) !== 1}
                  />
                </div>
              </div>

              <button type="submit" className="btn btn-primary w-100">
                {issueId ? "Update Issue" : "Create Issue"}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default IssueForm;
