package com.deloitte.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deloitte.dto.IssueDto;
import com.deloitte.dto.LoginRequestDto;
import com.deloitte.dto.UserDto;
import com.deloitte.dto.UserRequestDto;
import com.deloitte.service.UserService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/users")
@Tag(
        name = "User Management",
        description = "APIs for registering users, authentication, and "
                + "retrieving users and their associated issues.")
public class UserController {

    @Autowired
    private UserService userService;

    @Operation(
            summary = "Create a new user",
            description = "Registers a new user from the provided payload and "
                    + "returns the created user details.")
    @PostMapping
    public ResponseEntity<UserDto> addUser(@Valid @RequestBody UserRequestDto request) {
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(userService.addUser(request));
    }

    @Operation(
            summary = "Get all users",
            description = "Retrieves the complete list of users. "
                    + "Returns an empty list when no users exist.")
    @GetMapping
    public ResponseEntity<List<UserDto>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @Operation(
            summary = "Get issues by username",
            description = "Retrieves all issues associated with the user "
                    + "identified by the given username.")
    @GetMapping("/username/{username}/issues")
    public ResponseEntity<List<IssueDto>> getIssuesByUsername(@PathVariable String username) {
        return ResponseEntity.ok(userService.getIssuesByUsername(username));
    }

    @Operation(
            summary = "Get issues by user ID",
            description = "Retrieves all issues associated with the user "
                    + "identified by the given user ID.")
    @GetMapping("/{userId}/issues")
    public ResponseEntity<List<IssueDto>> getIssuesByUserId(@PathVariable Integer userId) {
        return ResponseEntity.ok(userService.getIssuesByUserId(userId));
    }

    @Operation(
            summary = "Get a user by ID",
            description = "Retrieves a single user identified by their unique ID.")
    @GetMapping("/{userId}")
    public ResponseEntity<UserDto> getUserById(@PathVariable Integer userId) {
        return ResponseEntity.ok(userService.getUserById(userId));
    }

    @Operation(
            summary = "Authenticate a user",
            description = "Validates the provided login credentials and returns "
                    + "the authenticated user's details on success.")
    @PostMapping("/login")
    public ResponseEntity<UserDto> login(@Valid @RequestBody LoginRequestDto request) {
        return ResponseEntity.ok(userService.login(request));
    }
}