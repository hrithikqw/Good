package com.deloitte.service;


import java.util.List;

import com.deloitte.entity.Issue;

public interface IssueService {
    Issue addIssue(Issue issue);
    List<Issue> getAllIssues();
    Issue getIssueById(Integer id);
    Issue updateIssue(Integer id, Issue issue);
    List<Issue> getIssuesByProject(Integer projectId);
    List<Issue> getIssuesByAssignee(Integer assignee);
}